﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MMTRecentOrdersCustomer
{
    public class RecentCustomerOrderViewModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
       
        public Order  Order{ get; set; }
        public Orders Orders { get; set; }
        public List<Products> Product { get; set; }
        public List<OrderItems> OrderItems { get; set; }
    }
}
