﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;


namespace MMTRecentOrdersCustomer
{
    public class OrderItems
    {
		[Key]
		public int OrderItemId { get; set; }
		public int OrderId { get; set; }
		public int ProductId { get; set; }
		public int Quantity { get; set; }
		public Decimal Price  { get; set; }
		public bool  Returnable { get; set; }
	}
}

