﻿using Microsoft.EntityFrameworkCore;
using MMTRecentOrdersCustomer;
using System;

namespace MMTRecentOrders.DAL
{
    public class RecentOrdersContext : DbContext
    {
        public RecentOrdersContext(DbContextOptions<RecentOrdersContext> options)
           : base(options)
        {
        }
        public DbSet<RecentCustomerOrder> RecentCustomerOrders { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<Products> Products { get; set; }

        public DbSet<OrderItems> OrderItems { get; set; }
    }
}
