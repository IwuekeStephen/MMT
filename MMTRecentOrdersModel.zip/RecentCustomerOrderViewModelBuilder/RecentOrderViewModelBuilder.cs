﻿using MMTRecentOrdersCustomer;
using MMTRecentOrdersRepository;
using MMTRecentOrdersService;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RecentCustomerOrderViewModelBuilder
{
    
    public class RecentOrderViewModelBuilder : IRecentOrderViewModelBuilder
    {
        private readonly IHttpUtilityService _httpUtility;
        private readonly IRecentOrdersRepo _recentOrderRepo;
        public RecentOrderViewModelBuilder(IHttpUtilityService httpUtility,
            IRecentOrdersRepo recentOrderRepol)
         {
            _httpUtility = httpUtility;
            _recentOrderRepo = recentOrderRepol;
         }
        public RecentCustomerOrderViewModel Build(Customer customer)
        {
            var user = customer.User;
            var customerId = customer.CustomerId;


            var cust = _httpUtility.GetCustomerDetailsUrl(user);
            if (cust == null)
            {
                var message = string.Format("Customer does not exist");
                return new RecentCustomerOrderViewModel();
            }

            JObject jObject = JObject.Parse(cust);
            var houseNo = (string)jObject.SelectToken("houseNumber");
            var street = (string)jObject.SelectToken("street");
            var town = (string)jObject.SelectToken("town");
            var postcode = (string)jObject.SelectToken("postcode");
            var firstName = (string)jObject.SelectToken("firstName");
            var lastName = (string)jObject.SelectToken("lastName");

            var ordersModel = _recentOrderRepo.GetRecentOrder(customerId);
            if (ordersModel.Any(m => m.OrderItems != null))
            {
                var order = ordersModel.Select(e => new
                {
                    OrderNumber = e.OrderId,
                    OrderDate = e.OrderDate,

                });
                List<Products> products = new List<Products>();
                var productVM = ordersModel.Select(e => e.OrderItems).ToList();
                products.Add(new Products()
                {
                    PriceEach = productVM.Select(s => s.Price).FirstOrDefault(),
                    ProductId = productVM.Select(s => s.ProductId).FirstOrDefault(),
                    Quantity = productVM.Select(s => s.Quantity).FirstOrDefault(),
                });

                return new RecentCustomerOrderViewModel
                {
                    FirstName = firstName,
                    LastName = lastName,
                    Order = new Order
                    {
                        OrderNumber = order.Select(s => s.OrderNumber).FirstOrDefault(),
                        OrderDate = order.Select(e => e.OrderDate).FirstOrDefault(),
                        DeliveryAddress = $"{ houseNo } {street} { street } {postcode}"
                    },

                    Product = products
                   
                };
            }

            return new RecentCustomerOrderViewModel();

        }
    }
}

