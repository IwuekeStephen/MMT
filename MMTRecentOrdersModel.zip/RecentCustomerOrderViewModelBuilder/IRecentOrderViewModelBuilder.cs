﻿using MMTRecentOrdersCustomer;
using System;

namespace RecentCustomerOrderViewModelBuilder
{
    public interface IRecentOrderViewModelBuilder
    {
        RecentCustomerOrderViewModel Build(Customer customer);

    } 
}
