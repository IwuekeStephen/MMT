﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace MMTRecentOrdersService
{
    public class HttpUtilityService : IHttpUtilityService
    {
        System.Net.Http.HttpClient _client = new System.Net.Http.HttpClient();
        private readonly IConfiguration _configuration;
        public HttpUtilityService(IConfiguration configuration)
        {
             _configuration = configuration;
        }
        public async Task<string> Download(string url)
        {
            var maxAttempts = 2;
            var attempt = 1;
            var done = false;

            while (!done && attempt <= maxAttempts)
            {
                var response = await _client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {

                    return await response.Content.ReadAsStringAsync();
                }
                else
                {
                    attempt++;
                }
            }
            return null;
        }

        public string GetCustomerDetailsUrl(string email)
        {
            var url = _configuration["CustomerDetailsUrl"];
            url = string.Format(url, email);
            var response = Task.Run(() => Download(url)).Result;

            return response;
        }
    }
}
