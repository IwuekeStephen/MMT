﻿using MMTRecentOrdersCustomer;
using System;
using System.Collections.Generic;

namespace MMTRecentOrdersRepository
{
    public interface IRecentOrdersRepo
    {
        List<Orders> GetRecentOrder(string customerId);
        }
}
