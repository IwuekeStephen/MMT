﻿using MMTRecentOrders.DAL;
using MMTRecentOrdersCustomer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MMTRecentOrdersRepository
{
    public class RecentOrdersRepo : IRecentOrdersRepo
    {
        private readonly RecentOrdersContext _recentOrdersContext;

        public RecentOrdersRepo(RecentOrdersContext recentOrdersContext)
        {
            _recentOrdersContext = recentOrdersContext;
        }
        public List<Orders> GetRecentOrder(string customerId)
        {
            List<Orders> orders = new List<Orders>();
            var query = from o in _recentOrdersContext.Orders
                        join oi in _recentOrdersContext.OrderItems on o.OrderId equals oi.OrderItemId
                        join p in _recentOrdersContext.Products on oi.ProductId equals p.ProductId
                        into MatchedOrders
                        from mo in MatchedOrders.DefaultIfEmpty() 
                        
                        orderby o.OrderDate descending
                        where o.CustomerId== customerId 
                        select new 
                        {
                          orderNumber = o.OrderId,
                          OrderDate =   o.OrderDate,
                          deliveryExpected = o.DeliveryExpected,
                          OrderItems = oi
                        };
                       var result =  query.FirstOrDefault();
            orders.Add(new Orders()
            {
                OrderDate = result.OrderDate,
                DeliveryExpected = result.deliveryExpected,
                OrderItems = result.OrderItems
            });
            return orders;
        }
    }
}
